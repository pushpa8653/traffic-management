import React from 'react';
import { useTraffic } from '../context/TrafficContext';
import { IntersectionCard } from './IntersectionCard';
import { SimulationControls } from './SimulationControls';

export const Dashboard: React.FC = () => {
  const { intersections, isSimulationRunning, toggleSimulation } = useTraffic();

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Traffic Management Dashboard</h2>
          <p className="mt-1 text-sm text-gray-600">
            Real-time monitoring and AI-powered signal adjustments for optimal traffic flow.
          </p>
        </div>
        <SimulationControls />
      </div>
      
      <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-6">
        {intersections.map((intersection) => (
          <IntersectionCard 
            key={intersection.id} 
            intersection={intersection} 
          />
        ))}
      </div>
      
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-lg font-medium text-gray-900 mb-4">System Overview</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm font-medium text-blue-800">Average Traffic Level</p>
            <p className="mt-2 text-2xl font-semibold text-blue-900">
              {Math.round(intersections.reduce((acc, int) => acc + int.trafficLevel, 0) / intersections.length)}%
            </p>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm font-medium text-green-800">System Efficiency</p>
            <p className="mt-2 text-2xl font-semibold text-green-900">
              {Math.round(80 + Math.random() * 15)}%
            </p>
          </div>
          <div className="bg-amber-50 p-4 rounded-lg">
            <p className="text-sm font-medium text-amber-800">Total Pedestrians</p>
            <p className="mt-2 text-2xl font-semibold text-amber-900">
              {intersections.reduce((acc, int) => acc + int.pedestrianCount, 0)}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};