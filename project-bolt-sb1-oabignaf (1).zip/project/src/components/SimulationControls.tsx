import React from 'react';
import { useTraffic } from '../context/TrafficContext';
import { Play, Pause, RefreshCw } from 'lucide-react';

export const SimulationControls: React.FC = () => {
  const { isSimulationRunning, toggleSimulation, resetSimulation } = useTraffic();

  return (
    <div className="flex space-x-2 mt-4 md:mt-0">
      <button
        onClick={toggleSimulation}
        className={`flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
          isSimulationRunning
            ? 'bg-amber-100 text-amber-800 hover:bg-amber-200'
            : 'bg-blue-100 text-blue-800 hover:bg-blue-200'
        }`}
      >
        {isSimulationRunning ? (
          <>
            <Pause className="h-4 w-4 mr-2" />
            Pause
          </>
        ) : (
          <>
            <Play className="h-4 w-4 mr-2" />
            Start
          </>
        )}
      </button>
      
      <button
        onClick={resetSimulation}
        className="flex items-center px-4 py-2 bg-gray-100 rounded-md text-sm font-medium text-gray-800 hover:bg-gray-200 transition-colors"
      >
        <RefreshCw className="h-4 w-4 mr-2" />
        Reset
      </button>
    </div>
  );
};