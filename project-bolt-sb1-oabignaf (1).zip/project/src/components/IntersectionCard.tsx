import React from 'react';
import { useTraffic } from '../context/TrafficContext';
import { Car, Users } from 'lucide-react';
import { TrafficLight } from './TrafficLight';
import { Intersection } from '../types/traffic';

interface IntersectionCardProps {
  intersection: Intersection;
}

export const IntersectionCard: React.FC<IntersectionCardProps> = ({ intersection }) => {
  const { id, trafficLevel, pedestrianCount, signalTiming, currentSignal } = intersection;
  const { updateTrafficLevel, updatePedestrianCount } = useTraffic();

  const handleTrafficChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updateTrafficLevel(id, parseInt(e.target.value));
  };

  const handlePedestrianChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    updatePedestrianCount(id, parseInt(e.target.value));
  };

  return (
    <div className="bg-white rounded-lg shadow overflow-hidden transition-all duration-200 hover:shadow-md">
      <div className="p-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-medium text-gray-900">Intersection {id + 1}</h3>
          <TrafficLight currentSignal={currentSignal} />
        </div>
        
        <div className="space-y-4">
          <div>
            <div className="flex justify-between mb-1">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Car className="h-4 w-4 mr-1" />
                Traffic Level
              </label>
              <span className="text-sm font-semibold text-blue-600">{trafficLevel}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={trafficLevel}
              onChange={handleTrafficChange}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
          </div>
          
          <div>
            <div className="flex justify-between mb-1">
              <label className="flex items-center text-sm font-medium text-gray-700">
                <Users className="h-4 w-4 mr-1" />
                Pedestrians
              </label>
              <span className="text-sm font-semibold text-amber-600">{pedestrianCount}</span>
            </div>
            <input
              type="range"
              min="0"
              max="50"
              value={pedestrianCount}
              onChange={handlePedestrianChange}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
            />
          </div>
        </div>
      </div>
      
      <div className="bg-gray-50 px-6 py-4">
        <h4 className="text-sm font-medium text-gray-700 mb-2">Signal Timing</h4>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <p className="text-xs text-gray-500">Green Time</p>
            <p className="text-lg font-semibold text-green-600">{signalTiming.greenTime}s</p>
          </div>
          <div>
            <p className="text-xs text-gray-500">Red Time</p>
            <p className="text-lg font-semibold text-red-600">{signalTiming.redTime}s</p>
          </div>
        </div>
      </div>
    </div>
  );
};