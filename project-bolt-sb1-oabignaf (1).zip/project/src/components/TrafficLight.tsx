import React from 'react';
import { SignalState } from '../types/traffic';

interface TrafficLightProps {
  currentSignal: SignalState;
}

export const TrafficLight: React.FC<TrafficLightProps> = ({ currentSignal }) => {
  return (
    <div className="flex flex-col items-center justify-center bg-gray-800 rounded-md p-2 w-10 h-20">
      <div 
        className={`w-6 h-6 rounded-full mb-1 ${
          currentSignal === 'red' ? 'bg-red-600 animate-pulse' : 'bg-red-900'
        }`}
      />
      <div 
        className={`w-6 h-6 rounded-full mb-1 ${
          currentSignal === 'yellow' ? 'bg-yellow-400 animate-pulse' : 'bg-yellow-900'
        }`}
      />
      <div 
        className={`w-6 h-6 rounded-full ${
          currentSignal === 'green' ? 'bg-green-500 animate-pulse' : 'bg-green-900'
        }`}
      />
    </div>
  );
};