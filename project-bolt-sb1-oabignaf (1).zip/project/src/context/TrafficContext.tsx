import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Intersection, SignalTiming, SignalState } from '../types/traffic';
import { adjustSignalTiming, getTrafficData } from '../utils/trafficUtils';

// Define the shape of our context
interface TrafficContextType {
  intersections: Intersection[];
  isSimulationRunning: boolean;
  toggleSimulation: () => void;
  resetSimulation: () => void;
  updateTrafficLevel: (id: number, level: number) => void;
  updatePedestrianCount: (id: number, count: number) => void;
}

// Create the context with default values
const TrafficContext = createContext<TrafficContextType>({
  intersections: [],
  isSimulationRunning: false,
  toggleSimulation: () => {},
  resetSimulation: () => {},
  updateTrafficLevel: () => {},
  updatePedestrianCount: () => {},
});

// Number of intersections to simulate
const MAX_INTERSECTIONS = 4;

// Create a provider component
export const TrafficProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [intersections, setIntersections] = useState<Intersection[]>([]);
  const [isSimulationRunning, setIsSimulationRunning] = useState(false);

  // Initialize intersections
  useEffect(() => {
    resetSimulation();
  }, []);

  // Run the simulation when it's active
  useEffect(() => {
    let simulationInterval: number | undefined;

    if (isSimulationRunning) {
      simulationInterval = window.setInterval(() => {
        setIntersections(prevIntersections => {
          return prevIntersections.map(intersection => {
            // In a real app, we would get live data here
            const newTrafficData = isSimulationRunning 
              ? getTrafficData(intersection.id)
              : { trafficLevel: intersection.trafficLevel, pedestrianCount: intersection.pedestrianCount };
            
            const newTiming = adjustSignalTiming(newTrafficData);
            
            // Toggle the signal based on timing
            let newSignal: SignalState = intersection.currentSignal;
            
            // Simplified logic for demo - in real app would be more complex time-based logic
            if (Math.random() > 0.7) {
              if (intersection.currentSignal === 'green') {
                newSignal = 'yellow';
              } else if (intersection.currentSignal === 'yellow') {
                newSignal = 'red';
              } else {
                newSignal = 'green';
              }
            }
            
            return {
              ...intersection,
              ...newTrafficData,
              signalTiming: newTiming,
              currentSignal: newSignal
            };
          });
        });
      }, 2000);
    }

    return () => {
      if (simulationInterval) {
        clearInterval(simulationInterval);
      }
    };
  }, [isSimulationRunning]);

  // Initialize or reset simulation
  const resetSimulation = () => {
    const initialIntersections: Intersection[] = Array.from({ length: MAX_INTERSECTIONS }).map((_, index) => {
      const trafficData = getTrafficData(index);
      const signalTiming = adjustSignalTiming(trafficData);

      return {
        id: index,
        ...trafficData,
        signalTiming,
        currentSignal: 'red' as SignalState
      };
    });
    
    setIntersections(initialIntersections);
    setIsSimulationRunning(false);
  };

  // Toggle simulation state
  const toggleSimulation = () => {
    setIsSimulationRunning(prev => !prev);
  };

  // Update traffic level for a specific intersection
  const updateTrafficLevel = (id: number, level: number) => {
    setIntersections(prevIntersections => {
      return prevIntersections.map(intersection => {
        if (intersection.id === id) {
          const newTiming = adjustSignalTiming({
            trafficLevel: level,
            pedestrianCount: intersection.pedestrianCount
          });
          
          return {
            ...intersection,
            trafficLevel: level,
            signalTiming: newTiming
          };
        }
        return intersection;
      });
    });
  };

  // Update pedestrian count for a specific intersection
  const updatePedestrianCount = (id: number, count: number) => {
    setIntersections(prevIntersections => {
      return prevIntersections.map(intersection => {
        if (intersection.id === id) {
          const newTiming = adjustSignalTiming({
            trafficLevel: intersection.trafficLevel,
            pedestrianCount: count
          });
          
          return {
            ...intersection,
            pedestrianCount: count,
            signalTiming: newTiming
          };
        }
        return intersection;
      });
    });
  };

  return (
    <TrafficContext.Provider
      value={{
        intersections,
        isSimulationRunning,
        toggleSimulation,
        resetSimulation,
        updateTrafficLevel,
        updatePedestrianCount
      }}
    >
      {children}
    </TrafficContext.Provider>
  );
};

// Custom hook for consuming the context
export const useTraffic = () => useContext(TrafficContext);