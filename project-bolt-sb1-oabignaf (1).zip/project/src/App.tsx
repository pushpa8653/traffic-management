import React from 'react';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { TrafficProvider } from './context/TrafficContext';

function App() {
  return (
    <TrafficProvider>
      <Layout>
        <Dashboard />
      </Layout>
    </TrafficProvider>
  );
}

export default App;