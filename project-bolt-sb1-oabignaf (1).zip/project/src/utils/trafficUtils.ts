import { TrafficData, SignalTiming } from '../types/traffic';

// Simulate getting real-time traffic data (would be replaced with actual sensor/API data)
export const getTrafficData = (intersectionId: number): TrafficData => {
  return {
    trafficLevel: Math.floor(Math.random() * 100),
    pedestrianCount: Math.floor(Math.random() * 50)
  };
};

// Adjust traffic signal based on AI logic
export const adjustSignalTiming = (data: TrafficData): SignalTiming => {
  let timing: SignalTiming = {
    greenTime: 30,
    redTime: 30
  };
  
  // Apply the AI logic from the C program
  if (data.trafficLevel > 70) {
    timing.greenTime = 60;
    timing.redTime = 30;
  } else if (data.trafficLevel > 40) {
    timing.greenTime = 45;
    timing.redTime = 45;
  } else {
    timing.greenTime = 30;
    timing.redTime = 60;
  }

  // Prioritize pedestrians during low traffic
  if (data.pedestrianCount > 20 && data.trafficLevel < 40) {
    timing.greenTime -= 10;
    timing.redTime += 10;
  }
  
  return timing;
};