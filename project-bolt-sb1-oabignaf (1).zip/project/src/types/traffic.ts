export type SignalState = 'red' | 'yellow' | 'green';

export interface TrafficData {
  trafficLevel: number; // 0-100
  pedestrianCount: number; // 0-50
}

export interface SignalTiming {
  greenTime: number; // seconds
  redTime: number; // seconds
}

export interface Intersection extends TrafficData {
  id: number;
  signalTiming: SignalTiming;
  currentSignal: SignalState;
}