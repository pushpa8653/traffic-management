import { TrafficData, SignalTiming, Intersection } from '../types/traffic';

// Generate random traffic data (simulates sensor input)
export const generateTrafficData = (): TrafficData => {
  return {
    trafficLevel: Math.floor(Math.random() * 100),
    pedestrianCount: Math.floor(Math.random() * 50),
    timeStamp: new Date()
  };
};

// AI logic to adjust signal timing based on traffic data
export const calculateSignalTiming = (data: TrafficData): SignalTiming => {
  let greenTime = 45;
  let redTime = 45;
  
  // Adjust based on traffic level
  if (data.trafficLevel > 70) {
    greenTime = 60;
    redTime = 30;
  } else if (data.trafficLevel > 40) {
    greenTime = 45;
    redTime = 45;
  } else {
    greenTime = 30;
    redTime = 60;
  }

  // Prioritize pedestrians during low traffic
  if (data.pedestrianCount > 20 && data.trafficLevel < 40) {
    greenTime -= 10;
    redTime += 10;
  }

  return {
    greenTime,
    redTime,
    cycleStartTime: new Date()
  };
};

// Get simulated intersections
export const initializeIntersections = (count: number): Intersection[] => {
  const intersections: Intersection[] = [];
  
  for (let i = 0; i < count; i++) {
    const trafficData = generateTrafficData();
    const signalTiming = calculateSignalTiming(trafficData);
    
    intersections.push({
      id: i,
      name: `Intersection ${i + 1}`,
      location: `Main St & ${i + 1}${getOrdinalSuffix(i + 1)} Ave`,
      trafficData,
      signalTiming,
      history: [
        { time: new Date(), trafficLevel: trafficData.trafficLevel }
      ]
    });
  }
  
  return intersections;
};

// Update intersection with new data
export const updateIntersection = (intersection: Intersection): Intersection => {
  const trafficData = generateTrafficData();
  const signalTiming = calculateSignalTiming(trafficData);
  
  // Keep only the last 20 history points
  const history = [
    ...intersection.history, 
    { time: new Date(), trafficLevel: trafficData.trafficLevel }
  ].slice(-20);
  
  return {
    ...intersection,
    trafficData,
    signalTiming,
    history
  };
};

// Helper for ordinal suffixes
const getOrdinalSuffix = (num: number): string => {
  const j = num % 10;
  const k = num % 100;
  
  if (j === 1 && k !== 11) {
    return "st";
  }
  if (j === 2 && k !== 12) {
    return "nd";
  }
  if (j === 3 && k !== 13) {
    return "rd";
  }
  return "th";
};