import React, { useEffect, useState } from 'react';
import { SignalTiming } from '../types/traffic';

interface TrafficLightProps {
  signalTiming: SignalTiming;
  className?: string;
}

type LightState = 'red' | 'green' | 'amber';

const TrafficLight: React.FC<TrafficLightProps> = ({ signalTiming, className }) => {
  const [currentLight, setCurrentLight] = useState<LightState>('red');
  const [remainingTime, setRemainingTime] = useState<number>(0);
  const [cycleTime, setCycleTime] = useState<number>(0);

  useEffect(() => {
    // Calculate total cycle time
    const totalCycle = signalTiming.greenTime + signalTiming.redTime + 6; // 6 seconds for amber (3 before green, 3 before red)
    setCycleTime(totalCycle);
    
    // Calculate time since cycle start
    const now = new Date();
    const elapsedSinceStart = Math.floor((now.getTime() - signalTiming.cycleStartTime.getTime()) / 1000);
    const timeInCycle = elapsedSinceStart % totalCycle;
    
    // Determine current light state
    if (timeInCycle < signalTiming.greenTime) {
      setCurrentLight('green');
      setRemainingTime(signalTiming.greenTime - timeInCycle);
    } else if (timeInCycle < signalTiming.greenTime + 3) {
      setCurrentLight('amber');
      setRemainingTime(signalTiming.greenTime + 3 - timeInCycle);
    } else if (timeInCycle < signalTiming.greenTime + 3 + signalTiming.redTime) {
      setCurrentLight('red');
      setRemainingTime(signalTiming.greenTime + 3 + signalTiming.redTime - timeInCycle);
    } else {
      setCurrentLight('amber');
      setRemainingTime(totalCycle - timeInCycle);
    }
    
    // Update every second
    const timer = setInterval(() => {
      const now = new Date();
      const elapsedSinceStart = Math.floor((now.getTime() - signalTiming.cycleStartTime.getTime()) / 1000);
      const timeInCycle = elapsedSinceStart % totalCycle;
      
      if (timeInCycle < signalTiming.greenTime) {
        setCurrentLight('green');
        setRemainingTime(signalTiming.greenTime - timeInCycle);
      } else if (timeInCycle < signalTiming.greenTime + 3) {
        setCurrentLight('amber');
        setRemainingTime(signalTiming.greenTime + 3 - timeInCycle);
      } else if (timeInCycle < signalTiming.greenTime + 3 + signalTiming.redTime) {
        setCurrentLight('red');
        setRemainingTime(signalTiming.greenTime + 3 + signalTiming.redTime - timeInCycle);
      } else {
        setCurrentLight('amber');
        setRemainingTime(totalCycle - timeInCycle);
      }
    }, 1000);
    
    return () => clearInterval(timer);
  }, [signalTiming]);

  return (
    <div className={`flex flex-col items-center ${className}`}>
      <div className="relative w-12 h-36 bg-gray-800 rounded-xl p-2 flex flex-col items-center justify-between">
        <div className={`w-8 h-8 rounded-full ${currentLight === 'red' ? 'bg-red-500 animate-pulse shadow-md shadow-red-300' : 'bg-red-900'}`}></div>
        <div className={`w-8 h-8 rounded-full ${currentLight === 'amber' ? 'bg-amber-400 animate-pulse shadow-md shadow-amber-200' : 'bg-amber-900'}`}></div>
        <div className={`w-8 h-8 rounded-full ${currentLight === 'green' ? 'bg-green-500 animate-pulse shadow-md shadow-green-300' : 'bg-green-900'}`}></div>
      </div>
      <div className="mt-2 text-sm font-medium text-center">
        <p className={`${
          currentLight === 'red' ? 'text-red-500' : 
          currentLight === 'amber' ? 'text-amber-400' : 'text-green-500'
        }`}>
          {remainingTime}s
        </p>
        <p className="text-xs text-gray-500">
          Cycle: {cycleTime}s
        </p>
      </div>
    </div>
  );
};

export default TrafficLight;