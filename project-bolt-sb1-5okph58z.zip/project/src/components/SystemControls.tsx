import React from 'react';
import { Play, Pause, Plus, Minus } from 'lucide-react';

interface SystemControlsProps {
  isPaused: boolean;
  simulationSpeed: number;
  onPauseToggle: () => void;
  onSpeedChange: (speed: number) => void;
}

const SystemControls: React.FC<SystemControlsProps> = ({
  isPaused,
  simulationSpeed,
  onPauseToggle,
  onSpeedChange
}) => {
  return (
    <div className="bg-white rounded-lg shadow-md p-4">
      <h3 className="text-lg font-semibold text-gray-900 mb-4">System Controls</h3>
      
      <div className="flex flex-col space-y-4">
        <div>
          <button
            onClick={onPauseToggle}
            className={`flex items-center justify-center w-full py-2 px-4 rounded-md transition-colors ${
              isPaused
                ? 'bg-green-100 text-green-700 hover:bg-green-200'
                : 'bg-red-100 text-red-700 hover:bg-red-200'
            }`}
          >
            {isPaused ? (
              <>
                <Play size={18} className="mr-2" />
                <span>Start Simulation</span>
              </>
            ) : (
              <>
                <Pause size={18} className="mr-2" />
                <span>Pause Simulation</span>
              </>
            )}
          </button>
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Simulation Speed: {simulationSpeed}x
          </label>
          <div className="flex items-center">
            <button
              onClick={() => onSpeedChange(Math.max(0.5, simulationSpeed - 0.5))}
              className="p-1 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors"
              disabled={simulationSpeed <= 0.5}
            >
              <Minus size={16} className="text-gray-700" />
            </button>
            
            <div className="flex-1 mx-3">
              <input
                type="range"
                min="0.5"
                max="3"
                step="0.5"
                value={simulationSpeed}
                onChange={(e) => onSpeedChange(parseFloat(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer"
              />
            </div>
            
            <button
              onClick={() => onSpeedChange(Math.min(3, simulationSpeed + 0.5))}
              className="p-1 rounded-full bg-gray-200 hover:bg-gray-300 transition-colors"
              disabled={simulationSpeed >= 3}
            >
              <Plus size={16} className="text-gray-700" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SystemControls;