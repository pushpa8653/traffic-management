import React from 'react';

interface TrafficLevelIndicatorProps {
  level: number;
  showLabel?: boolean;
  className?: string;
}

const TrafficLevelIndicator: React.FC<TrafficLevelIndicatorProps> = ({ 
  level, 
  showLabel = true,
  className = ''
}) => {
  // Get color based on traffic level
  const getColor = () => {
    if (level < 30) return 'bg-green-500';
    if (level < 60) return 'bg-amber-400';
    return 'bg-red-500';
  };
  
  // Get text based on traffic level
  const getText = () => {
    if (level < 30) return 'Light';
    if (level < 60) return 'Moderate';
    return 'Heavy';
  };

  return (
    <div className={`flex flex-col ${className}`}>
      <div className="flex items-center">
        <div className="w-full bg-gray-200 rounded-full h-2.5">
          <div 
            className={`h-2.5 rounded-full ${getColor()}`} 
            style={{ width: `${level}%` }}
            data-testid="traffic-level-bar"
          ></div>
        </div>
        {showLabel && (
          <span className="ml-2 text-sm font-medium text-gray-700 w-16">
            {level}%
          </span>
        )}
      </div>
      {showLabel && (
        <span className={`text-xs mt-1 font-medium ${
          level < 30 ? 'text-green-700' : 
          level < 60 ? 'text-amber-600' : 'text-red-700'
        }`}>
          {getText()}
        </span>
      )}
    </div>
  );
};

export default TrafficLevelIndicator;