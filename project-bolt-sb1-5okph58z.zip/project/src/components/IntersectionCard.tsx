import React from 'react';
import { Intersection } from '../types/traffic';
import TrafficLight from './TrafficLight';
import TrafficLevelIndicator from './TrafficLevelIndicator';
import { Users } from 'lucide-react';

interface IntersectionCardProps {
  intersection: Intersection;
}

const IntersectionCard: React.FC<IntersectionCardProps> = ({ intersection }) => {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden transition-all hover:shadow-lg">
      <div className="px-6 py-4">
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">{intersection.name}</h3>
            <p className="text-sm text-gray-500">{intersection.location}</p>
          </div>
          <TrafficLight signalTiming={intersection.signalTiming} />
        </div>
        
        <div className="mt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Traffic Level</span>
            <span className="text-sm text-gray-500">
              Last updated: {intersection.trafficData.timeStamp.toLocaleTimeString()}
            </span>
          </div>
          <TrafficLevelIndicator level={intersection.trafficData.trafficLevel} />
        </div>
        
        <div className="mt-4 flex justify-between items-center">
          <div className="flex items-center">
            <Users size={18} className="text-blue-500 mr-2" />
            <span className="text-sm font-medium text-gray-700">
              Pedestrians: {intersection.trafficData.pedestrianCount}
            </span>
          </div>
          
          <div>
            <span className="text-xs font-medium text-gray-500">
              Green: {intersection.signalTiming.greenTime}s
            </span>
            <span className="mx-2 text-gray-300">|</span>
            <span className="text-xs font-medium text-gray-500">
              Red: {intersection.signalTiming.redTime}s
            </span>
          </div>
        </div>
        
        <div className="mt-4 pt-4 border-t border-gray-100">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-gray-700">Historical Traffic</span>
          </div>
          <div className="flex h-20">
            {intersection.history.map((point, index) => (
              <div 
                key={index} 
                className="flex-1 flex items-end"
              >
                <div 
                  className={`w-full ${
                    point.trafficLevel < 30 ? 'bg-green-400' : 
                    point.trafficLevel < 60 ? 'bg-amber-400' : 'bg-red-400'
                  } rounded-sm mx-0.5`} 
                  style={{ height: `${point.trafficLevel}%` }}
                ></div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default IntersectionCard;