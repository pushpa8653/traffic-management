import React from 'react';
import { Intersection } from '../types/traffic';

interface StatisticCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  trendDescription?: string;
  className?: string;
}

const StatisticCard: React.FC<StatisticCardProps> = ({
  title,
  value,
  icon,
  trend,
  trendValue,
  trendDescription,
  className = ''
}) => {
  return (
    <div className={`bg-white rounded-lg shadow-md p-4 ${className}`}>
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <div className="text-gray-400">
          {icon}
        </div>
      </div>
      
      <div className="flex items-end">
        <p className="text-2xl font-semibold text-gray-900">{value}</p>
        
        {trend && trendValue && (
          <div className={`ml-2 flex items-center text-sm ${
            trend === 'up' ? 'text-red-500' : 
            trend === 'down' ? 'text-green-500' : 'text-gray-500'
          }`}>
            <span>{trendValue}</span>
            {trendDescription && (
              <span className="ml-1 text-xs text-gray-500">{trendDescription}</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

// Helper function to calculate stats from intersections
export const calculateStatistics = (intersections: Intersection[]) => {
  // Average traffic level
  const avgTraffic = intersections.reduce(
    (sum, intersection) => sum + intersection.trafficData.trafficLevel, 0
  ) / intersections.length;
  
  // Total pedestrians
  const totalPedestrians = intersections.reduce(
    (sum, intersection) => sum + intersection.trafficData.pedestrianCount, 0
  );
  
  // Congested intersections (traffic level > 70)
  const congestedCount = intersections.filter(
    intersection => intersection.trafficData.trafficLevel > 70
  ).length;
  
  // Average green time
  const avgGreenTime = intersections.reduce(
    (sum, intersection) => sum + intersection.signalTiming.greenTime, 0
  ) / intersections.length;
  
  return {
    avgTraffic: Math.round(avgTraffic),
    totalPedestrians,
    congestedCount,
    avgGreenTime: Math.round(avgGreenTime)
  };
};

export default StatisticCard;