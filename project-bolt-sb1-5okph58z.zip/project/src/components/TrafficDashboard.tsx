import React, { useState, useEffect } from 'react';
import { Intersection, TrafficSystemState } from '../types/traffic';
import { initializeIntersections, updateIntersection } from '../utils/trafficSimulation';
import IntersectionCard from './IntersectionCard';
import SystemControls from './SystemControls';
import StatisticCard, { calculateStatistics } from './StatisticCard';
import { Activity, AlertTriangle, Clock, Users } from 'lucide-react';

const TrafficDashboard: React.FC = () => {
  const [systemState, setSystemState] = useState<TrafficSystemState>({
    intersections: initializeIntersections(4),
    lastUpdated: new Date(),
    simulationSpeed: 1,
    isPaused: false
  });
  
  const [prevStats, setPrevStats] = useState({
    avgTraffic: 0,
    totalPedestrians: 0,
    congestedCount: 0,
    avgGreenTime: 0
  });
  
  // Update system state periodically
  useEffect(() => {
    if (systemState.isPaused) {
      return;
    }
    
    const interval = setInterval(() => {
      // Store current stats for trend calculation
      const currentStats = calculateStatistics(systemState.intersections);
      setPrevStats(currentStats);
      
      // Update all intersections
      const updatedIntersections = systemState.intersections.map(updateIntersection);
      
      setSystemState({
        ...systemState,
        intersections: updatedIntersections,
        lastUpdated: new Date()
      });
    }, 3000 / systemState.simulationSpeed); // Adjust update frequency based on simulation speed
    
    return () => clearInterval(interval);
  }, [systemState]);
  
  // Toggle pause state
  const handlePauseToggle = () => {
    setSystemState({
      ...systemState,
      isPaused: !systemState.isPaused
    });
  };
  
  // Change simulation speed
  const handleSpeedChange = (speed: number) => {
    setSystemState({
      ...systemState,
      simulationSpeed: speed
    });
  };
  
  // Calculate current statistics
  const stats = calculateStatistics(systemState.intersections);
  
  // Calculate trends
  const getTrend = (current: number, previous: number): 'up' | 'down' | 'neutral' => {
    if (current > previous) return 'up';
    if (current < previous) return 'down';
    return 'neutral';
  };
  
  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <h1 className="text-xl font-semibold text-gray-900">
              AI-Powered Traffic Management System
            </h1>
            <p className="text-sm text-gray-500">
              Last updated: {systemState.lastUpdated.toLocaleTimeString()}
            </p>
          </div>
        </div>
      </header>
      
      <main className="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
        <div className="mb-6 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4">
          <StatisticCard 
            title="Average Traffic Level" 
            value={`${stats.avgTraffic}%`}
            icon={<Activity size={20} />}
            trend={getTrend(stats.avgTraffic, prevStats.avgTraffic)}
            trendValue={`${Math.abs(stats.avgTraffic - prevStats.avgTraffic)}%`}
            trendDescription="vs previous update"
          />
          
          <StatisticCard 
            title="Total Pedestrians" 
            value={stats.totalPedestrians}
            icon={<Users size={20} />}
            trend={getTrend(stats.totalPedestrians, prevStats.totalPedestrians)}
            trendValue={`${Math.abs(stats.totalPedestrians - prevStats.totalPedestrians)}`}
          />
          
          <StatisticCard 
            title="Congested Intersections" 
            value={`${stats.congestedCount}/${systemState.intersections.length}`}
            icon={<AlertTriangle size={20} />}
            trend={getTrend(stats.congestedCount, prevStats.congestedCount)}
            trendValue={`${Math.abs(stats.congestedCount - prevStats.congestedCount)}`}
          />
          
          <StatisticCard 
            title="Average Green Time" 
            value={`${stats.avgGreenTime}s`}
            icon={<Clock size={20} />}
            trend={getTrend(stats.avgGreenTime, prevStats.avgGreenTime)}
            trendValue={`${Math.abs(stats.avgGreenTime - prevStats.avgGreenTime)}s`}
          />
        </div>
        
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
          <div className="lg:col-span-1">
            <SystemControls 
              isPaused={systemState.isPaused}
              simulationSpeed={systemState.simulationSpeed}
              onPauseToggle={handlePauseToggle}
              onSpeedChange={handleSpeedChange}
            />
          </div>
          
          <div className="lg:col-span-3">
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              {systemState.intersections.map((intersection) => (
                <IntersectionCard 
                  key={intersection.id} 
                  intersection={intersection} 
                />
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default TrafficDashboard;