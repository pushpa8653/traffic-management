export interface TrafficData {
  trafficLevel: number; // 0-100
  pedestrianCount: number;
  timeStamp: Date;
}

export interface SignalTiming {
  greenTime: number; // seconds
  redTime: number; // seconds
  cycleStartTime: Date;
}

export interface Intersection {
  id: number;
  name: string;
  location: string;
  trafficData: TrafficData;
  signalTiming: SignalTiming;
  history: Array<{
    time: Date;
    trafficLevel: number;
  }>;
}

export interface TrafficSystemState {
  intersections: Intersection[];
  lastUpdated: Date;
  simulationSpeed: number;
  isPaused: boolean;
}