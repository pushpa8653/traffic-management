import React from 'react';
import TrafficDashboard from './components/TrafficDashboard';

function App() {
  return (
    <div className="app">
      <TrafficDashboard />
    </div>
  );
}

export default App;